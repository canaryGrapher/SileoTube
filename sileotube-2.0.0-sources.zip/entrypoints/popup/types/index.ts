import * as StorageTypes from './storage';

export { StorageTypes };