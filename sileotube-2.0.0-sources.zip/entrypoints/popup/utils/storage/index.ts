import { handleFeatureToggle } from './handleFeatureToggle';

export { handleFeatureToggle };