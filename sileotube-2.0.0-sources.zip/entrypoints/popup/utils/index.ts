import * as StorageUtils from './storage';

export { StorageUtils };