import { getSettingsHandler, updateSettingHandler } from './getterAndSetter';

export { getSettingsHandler, updateSettingHandler };