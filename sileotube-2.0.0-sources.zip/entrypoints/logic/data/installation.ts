const INSTALL_URL = 'https://workvar.com/products/sileotube?redirectType=install';
const UNINSTALL_URL = 'https://workvar.com/products/uninstallsurvey/sileotube';

export { INSTALL_URL, UNINSTALL_URL };