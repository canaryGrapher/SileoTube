import { INSTALL_URL, UNINSTALL_URL } from './installation';
import { DEFAULT_SETTINGS } from './storage';

export { INSTALL_URL, UNINSTALL_URL, DEFAULT_SETTINGS };