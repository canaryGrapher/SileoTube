import { ExtensionSettings } from './storage';

export type { ExtensionSettings };