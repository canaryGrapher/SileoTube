import HomePageOptimizations from './homePage';
import WatchPageOptimizations from './watchPage';
import ShortsPageOptimizations from './shortsPage';

export { HomePageOptimizations, WatchPageOptimizations, ShortsPageOptimizations };