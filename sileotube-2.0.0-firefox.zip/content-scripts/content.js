var content=(function(){"use strict";function K(e){return e}const b=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,E=async()=>{if(document.getElementById("sileotube-shorts-recommendation-removal"))return;const t=document.createElement("style");t.id="sileotube-shorts-recommendation-removal",t.textContent=`
        #contents > grid-shelf-view-model { 
          display: none; 
        }
        ytd-video-renderer:has(a[href^="/shorts/"]) {
          display: none;
        }
        #items > ytd-mini-guide-entry-renderer[aria-label='Shorts'] {
          display: none;
        }
        ytd-rich-section-renderer {
          display: none;
        }
        #contents > ytd-reel-shelf-renderer {
          display: none;
        }
        ytd-reel-shelf-renderer {
          display: none;
        }
    `,document.documentElement.appendChild(t)},w=()=>{const e=document.getElementById("sileotube-shorts-recommendation-removal");e&&e.remove()},C=e=>{e?E():w()},S=()=>{const e=document.getElementById("sileotube-watch-page-comments-focus");e&&e.remove()},I=()=>{const e=document.getElementById("sileotube-watch-page-comments-focus");e&&e.remove();const t=document.createElement("style");t.id="sileotube-watch-page-comments-focus",t.textContent=`
    .ytd-comments {
      display: none;
    }
  `,document.documentElement.appendChild(t)},B=e=>{e?I():S()},T=()=>{if(document.getElementById("sileotube-sidebar-removal-focus"))return;const e=document.createElement("style");e.id="sileotube-sidebar-removal-focus",e.textContent=`
        #guide {
            display: none;
        }
        #guide-button {
            display: none;
        }
        #page-manager {
            margin: 0;
        }
        #content > ytd-mini-guide-renderer {
            display: none;
        }
  `,document.documentElement.appendChild(e)},N=()=>{const e=document.getElementById("sileotube-sidebar-removal-focus");e&&e.remove()},z=e=>{e?T():N()},A=()=>{const e=[{url:"https://ik.imagekit.io/canarygrapher/sileotube/images/photo-1761807446688-d87aea44ecb2_7xuNdATP_.jpg?updatedAt=1761851430009",description:"Woman looking out in a forest setting",photographer:{name:"Valentina Kondrasyuk",url:"https://unsplash.com/@valentinakond"},source:{name:"Unsplash",url:"https://unsplash.com/photos/woman-looking-out-in-a-forest-setting-A8JPF1-kixA?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText"}},{url:"https://ik.imagekit.io/canarygrapher/sileotube/images/photo-1761074499285-5ab0e10b07ee_U-WfwKOAk.jpg?updatedAt=1761851429999",description:"A squirrel sitting on a wooden post",photographer:{name:"Dmytro Koplyk",url:"https://unsplash.com/@dkoplyk"},source:{name:"Unsplash",url:"https://unsplash.com/photos/a-squirrel-sits-on-a-wooden-post-1h8KSlNeYek"}},{url:"https://ik.imagekit.io/canarygrapher/sileotube/images/deadlifting_2U_KrIN0y.jpeg?updatedAt=1761851083757",description:"Man deadlifting weights",photographer:{name:"Victor Freitas",url:"https://unsplash.com/@victorfreitas"},source:{name:"Unsplash",url:"https://unsplash.com/photos/man-holding-dumbbells-qZ-U9z4TQ6A"}},{url:"https://ik.imagekit.io/canarygrapher/sileotube/images/photo-1513113406068-fff36fa8f987_hzU4MquCFc.jpg",description:"Two people riding in car on road",photographer:{name:"Nick Brugiono",url:"https://unsplash.com/@nickbrugioni"},source:{name:"Unsplash",url:"https://unsplash.com/photos/two-people-riding-in-car-on-road-RsAMlfzza9Y"}}];return e[Math.floor(Math.random()*e.length)]},_=()=>{const e=document.querySelector("#content"),t=document.createElement("div");t.id="sileotube-search-bar";const o=document.createElement("h1");o.id="sileotube-search-bar-heading",o.textContent="What are you watching today?",t.appendChild(o);const n=document.createElement("div");n.id="sileotube-search-bar-box";const r=document.createElement("input");r.id="sileotube-search-bar-input",r.placeholder="Search",r.type="text",r.addEventListener("input",i=>{const a=i.target,c=document.querySelector("#center > yt-searchbox > div.ytSearchboxComponentInputBox.ytSearchboxComponentInputBoxDark > form > input");c&&(c.value=a.value,c.dispatchEvent(new Event("input",{bubbles:!0})))}),n.appendChild(r);const s=document.createElement("button");s.id="sileotube-search-bar-button",s.textContent="Search",s.addEventListener("click",()=>{const i=document.querySelector("#center > yt-searchbox > button");i&&i.click()}),n.appendChild(s),t.appendChild(n),e?.prepend(t),r.addEventListener("keydown",i=>{i.key==="Enter"&&(i.preventDefault(),document.getElementById("sileotube-search-bar-button")?.click())})},P=()=>{const e=document.getElementById("sileotube-search-bar");e&&e.remove()},U=()=>{if(document.getElementById("sileotube-homepage-focus"))return;const t=document.createElement("style");t.id="sileotube-homepage-focus";const o=A();t.textContent=`
        ytd-rich-item-renderer {
          display: none;
        }
        ytd-ghost-grid-renderer {
          display: none;
        }
        ytd-continuation-item-renderer {
          display: none;
        }
        ytd-rich-section-renderer {
          display: none;
        }
        #header {
          display: none;
        }
        body > ytd-app { 
          background-color: #3C3C3C;
          min-height: 100vh;
          position: relative;
          background-image: url('${o.url}');
          background-size: cover;
          background-position: center;
          background-repeat: no-repeat;
        }
        #frosted-glass {
          display: none;
        }

        #content {
          postision: absolute;
          top: 0;
          left: 0;
          width: 100vw;
          height: 100vh;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          gap: 1 rem;
          padding: 1rem;
        }

        #background {
          display: none;
        }

        #sileotube-search-bar {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          gap: 1rem;
          padding: 1rem;
          top: 35%;
          position: absolute;
        }

        #sileotube-search-bar-heading {
          color: white;
          font-size: 5rem;
          font-weight: 600;
          margin: 0 0 1rem 0;
          text-align: center;
        }

        #sileotube-search-bar > div {
          display: flex;
          flex-direction: row;
          justify-content: center;
          align-items: center;
          gap: 0;
          box-shadow: 0 0 8px 2px rgb(166, 0, 0), 0 0 8px 2px rgb(166, 0, 0);
          border: 1px solid rgb(166, 0, 0);
        }

        #sileotube-search-bar-box {
          background: rgba(0, 0, 0, 0.1);
          backdrop-filter: blur(2px);
          -webkit-backdrop-filter: blur(2px);
          border: 1px solid #000;
          border-radius: 10px;
          overflow: hidden;
        }

        #sileotube-search-bar > div > input {
          width: 35vw;
          height: 50px;
          border: none;
          outline: none;
          font-size: 16px;
          border-radius: 10px 0 0 10px;
          padding: 0 15px;
          background-color: rgba(18, 18, 18, 0.7);
          color: white;
        }

        #sileotube-search-bar > div > button {
          width: 120px;
          height: 50px;
          border: none;
          outline: none;
          background-color: #FF0000;
          color: white;
          border-radius: 0 10px 10px 0;
          cursor: pointer;
        }

        #sileotube-search-bar-button:hover {
          background-color:rgb(166, 0, 0);
        }

        #center > yt-searchbox, #center > yt-icon-button, #center > #voice-search-button, #center > #ai-companion-button {
          visibility: hidden;
        }

        #sileotube-image-ack {
          position: absolute;
          bottom: 5%;
          left: 50%;
          transform: translateX(-50%);
          color: rgba(255,255,255,0.9);
          font-size: 12px;
          text-align: center;
        }

        .sileotube-image-ack-description {
          font-size: 18px;
          text-align: center;
          padding-bottom: 10px;
        }

        .sileotube-image-ack-photographer { 
          color: #979797; 
          font-size: 12px;
        }

        .sileotube-image-ack-photographer a { 
          color: #979797;    
          text-decoration: underline; 
          cursor: pointer;
        }
      `,document.documentElement.appendChild(t),setTimeout(()=>{_();const n=document.getElementById("sileotube-image-ack");n&&n.remove();const r=document.createElement("div");r.id="sileotube-image-ack";const s=document.createElement("div");s.className="sileotube-image-ack-description",s.textContent=o.description,r.appendChild(s);const i=document.createElement("div");i.className="sileotube-image-ack-photographer",i.textContent="Photo by ";const a=document.createElement("a");a.href=o.photographer.url,a.target="_blank",a.rel="noopener noreferrer",a.textContent=o.photographer.name,i.appendChild(a),i.appendChild(document.createTextNode(" on "));const c=document.createElement("a");c.href=o.source.url,c.target="_blank",c.rel="noopener noreferrer",c.textContent=o.source.name,i.appendChild(c),r.appendChild(i),document.body.appendChild(r)},500)},v=()=>{const e=document.getElementById("sileotube-homepage-focus");e&&e.remove(),setTimeout(()=>{P();const t=document.getElementById("sileotube-image-ack");t&&t.remove()},500)},F=(e,t)=>{t==="/"&&e?U():v()},L=()=>{const e=document.getElementById("sileotube-watch-page-focus");e&&e.remove();const t=document.createElement("style");t.id="sileotube-watch-page-focus",t.textContent=`
    #secondary {
      display: none;
    }
  `,document.documentElement.appendChild(t)},k=()=>{const e=document.getElementById("sileotube-watch-page-focus");e&&e.remove()},O=(e,t)=>{t==="/watch"&&e?L():k()},l={url:"https://ik.imagekit.io/canarygrapher/sileotube/images/Netflix_gJt-_mp3Z.png?updatedAt=1761850643241",description:"A television with Netflix logo lit on it",photographer:{name:"Thibault Penin",url:"https://unsplash.com/@thibaultpenin"},source:{name:"Unsplash",url:"https://unsplash.com/photos/a-television-with-the-netflix-logo-lit-up-in-the-dark-GrzoKN1aqSg"}},R=()=>{document.querySelector("video")?.pause();const e=document.getElementById("sileotube-shorts-blocker-focus");e&&e.remove();const t=document.createElement("style");t.id="sileotube-shorts-blocker-focus",t.textContent=`
  /* Container for the overlay */
  #sileotube-shorts-blocker-overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: #3C3C3C;
    background-image: url('${l.url}');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 9999;
    margin-bottom: 1rem;
  }


  /* Center panel */
  #sileotube-shorts-blocker-center {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1.5rem;
    padding: 2rem 3rem;
    backdrop-filter: blur(2px);
    -webkit-backdrop-filter: blur(2px);
  }

  /* Heading */
  #sileotube-shorts-blocker-heading {
    color: #ffffff;
    text-align: center;
    font-size: 6rem;
    line-height: 1.1;
    font-weight: 600;
  }

  /* Red action button */
  #sileotube-shorts-blocker-home-button {
    padding: 0 24px;
    height: 52px;
    min-width: 240px;
    color: #ffffff;
    background-color: #FF0000;
    border: none;
    border-radius: 14px;
    cursor: pointer;
    font-size: 20px;
    font-weight: 600;
  }

  #sileotube-shorts-blocker-home-button:hover {
    background-color:rgb(166, 0, 0);
  }

  /* Image acknowledgement */
  #sileotube-shorts-image-ack {
    margin-top: 8px;
    color: rgba(255,255,255,0.9);
    font-size: 12px;
    text-align: center;
  }
  .sileotube-shorts-image-ack-description { font-size: 14px; padding-bottom: 6px; }
  .sileotube-shorts-image-ack-photographer { color: #979797; font-size: 12px; }
  .sileotube-shorts-image-ack-photographer a { color: #979797; text-decoration: underline; cursor: pointer; }
`,document.documentElement.appendChild(t)},M=()=>{const e=document.getElementById("sileotube-shorts-blocker-overlay");e&&e.remove();const t=document.querySelector("#shorts-container"),o=document.createElement("div");o.id="sileotube-shorts-blocker-overlay";const n=document.createElement("div");n.id="sileotube-shorts-blocker-center";const r=document.createElement("h1");r.id="sileotube-shorts-blocker-heading",r.appendChild(document.createTextNode("Shorts?")),r.appendChild(document.createElement("br")),r.appendChild(document.createTextNode("Seriously?")),n.appendChild(r);const s=document.createElement("button");s.id="sileotube-shorts-blocker-home-button",s.textContent="Take me back to focus mode!",s.onclick=()=>window.location.href="/",n.appendChild(s);const i=document.getElementById("sileotube-shorts-image-ack");i&&i.remove();const a=document.createElement("div");a.id="sileotube-shorts-image-ack";const c=document.createElement("div");c.className="sileotube-shorts-image-ack-description",c.textContent=l.description,a.appendChild(c);const d=document.createElement("div");d.className="sileotube-shorts-image-ack-photographer",d.appendChild(document.createTextNode("Photo by "));const u=document.createElement("a");u.href=l.photographer.url,u.target="_blank",u.rel="noopener noreferrer",u.textContent=l.photographer.name,d.appendChild(u),d.appendChild(document.createTextNode(" on "));const p=document.createElement("a");p.href=l.source.url,p.target="_blank",p.rel="noopener noreferrer",p.textContent=l.source.name,d.appendChild(p),a.appendChild(d),n.appendChild(a),o.appendChild(n),t?.appendChild(o)},q=()=>{R(),M()},x=()=>{const e=document.getElementById("sileotube-shorts-blocker-focus"),t=document.getElementById("sileotube-shorts-blocker-overlay"),o=document.getElementById("sileotube-shorts-image-ack");t&&t.remove(),o&&o.remove(),e&&e.remove()},D=(e,t)=>{t.includes("/shorts")&&e?q():x()},W={matches:["*://*.youtube.com/*"],main(){b.runtime.onMessage.addListener(e=>{e.type==="SILEOTUBE:YOUTUBE PAGE UPDATED"&&(F(e.settings.pages.homepage,e.path),O(e.settings.pages.watch,e.path),D(e.settings.pages.shorts,e.path),B(e.settings.features.comments),z(e.settings.features.sidebar),C(e.settings.features.shortsRecommendations))})}};function m(e,...t){}const $={debug:(...e)=>m(console.debug,...e),log:(...e)=>m(console.log,...e),warn:(...e)=>m(console.warn,...e),error:(...e)=>m(console.error,...e)};class f extends Event{constructor(t,o){super(f.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=o}static EVENT_NAME=y("wxt:locationchange")}function y(e){return`${b?.runtime?.id}:content:${e}`}function j(e){let t,o;return{run(){t==null&&(o=new URL(location.href),t=e.setInterval(()=>{let n=new URL(location.href);n.href!==o.href&&(window.dispatchEvent(new f(n,o)),o=n)},1e3))}}}class h{constructor(t,o){this.contentScriptName=t,this.options=o,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=y("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=j(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return b.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,o){const n=setInterval(()=>{this.isValid&&t()},o);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(t,o){const n=setTimeout(()=>{this.isValid&&t()},o);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(t){const o=requestAnimationFrame((...n)=>{this.isValid&&t(...n)});return this.onInvalidated(()=>cancelAnimationFrame(o)),o}requestIdleCallback(t,o){const n=requestIdleCallback((...r)=>{this.signal.aborted||t(...r)},o);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(t,o,n,r){o==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(o.startsWith("wxt:")?y(o):o,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),$.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:h.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){const o=t.data?.type===h.SCRIPT_STARTED_MESSAGE_TYPE,n=t.data?.contentScriptName===this.contentScriptName,r=!this.receivedMessageIds.has(t.data?.messageId);return o&&n&&r}listenForNewerScripts(t){let o=!0;const n=r=>{if(this.verifyScriptStartedEvent(r)){this.receivedMessageIds.add(r.data.messageId);const s=o;if(o=!1,s&&t?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}}function G(){}function g(e,...t){}const V={debug:(...e)=>g(console.debug,...e),log:(...e)=>g(console.log,...e),warn:(...e)=>g(console.warn,...e),error:(...e)=>g(console.error,...e)};return(async()=>{try{const{main:e,...t}=W,o=new h("content",t);return await e(o)}catch(e){throw V.error('The content script "content" crashed on startup!',e),e}})()})();
content;